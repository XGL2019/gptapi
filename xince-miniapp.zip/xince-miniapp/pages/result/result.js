const app = getApp()
const MBTI = [
  {dim:"EI"},{dim:"SN"},{dim:"TF"},{dim:"JP"},{dim:"EI"},{dim:"SN"},{dim:"TF"},{dim:"JP"},
]

Page({
  data: { loading: true, resultType: "", analysis: "" },
  onLoad(options) {
    const type = options.type || "mbti"
    const answers = wx.getStorageSync(type + "_answers") || []
    if (type === "mbti") this.mbtiResult(answers)
    else this.careerResult(answers)
  },
  mbtiResult(answers) {
    const s = {E:0,I:0,S:0,N:0,T:0,F:0,J:0,P:0}
    answers.forEach((a,i) => { const d=MBTI[i].dim; s[d[0]]+=a==0?1:0; s[d[1]]+=a==1?1:0 })
    const mbti = (s.E>=s.I?"E":"I")+(s.S>=s.N?"S":"N")+(s.T>=s.F?"T":"F")+(s.J>=s.P?"J":"P")
    this.setData({ resultType: mbti })
    this.aiAnalyze(`用户是${mbti}型人格。作为心理咨询师，请分析：1.性格画像3句 2.职业方向3个 3.感情建议2句。用「」标出关键短句。总共200字以内。`)
  },
  careerResult(answers) {
    const t=[0,0,0,0]; answers.forEach(a=>{t[a]++})
    const types=["分析型","社交型","创意型","执行型"]
    const best=types[t.indexOf(Math.max(...t))]
    this.setData({ resultType: best })
    this.aiAnalyze(`用户是${best}人才。推荐3个职业方向各一句话+一条建议。总共100字以内。`)
  },
  aiAnalyze(prompt) {
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: { model: g.model, messages: [{role:"user",content:prompt}], max_tokens: 400 },
      success: (r) => {
        this.setData({ analysis: r.data.choices?.[0]?.message?.content || "分析失败", loading: false })
      },
      fail: () => this.setData({ analysis: "网络异常", loading: false })
    })
  },
  goHome() { wx.reLaunch({ url: "/pages/index/index" }) }
})
