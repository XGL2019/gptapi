const app = getApp()

// 20题MBTI维度定义（与test.js一致）
const MBTI_DIMS = [
  "EI","SN","TF","JP","EI","SN","TF","JP",
  "EI","SN","TF","JP","EI","SN","TF","JP",
  "EI","SN","TF","JP",
]

Page({
  data: {
    loading: true, resultType: "", analysis: "",
    bars: [],          // 可视化数据 [{label, left, right, leftPct, rightPct}]
    shareTitle: "",    // 分享标题
  },
  onLoad(options) {
    const type = options.type || "mbti"
    const answers = wx.getStorageSync(type + "_answers") || []
    if (type === "mbti") this.mbtiResult(answers)
    else this.careerResult(answers)
  },
  mbtiResult(answers) {
    if (answers.length > MBTI_DIMS.length) answers = answers.slice(0, MBTI_DIMS.length)
    const s = {E:0,I:0,S:0,N:0,T:0,F:0,J:0,P:0}
    answers.forEach((a,i) => { const d=MBTI_DIMS[i]; s[d[0]]+=a==0?1:0; s[d[1]]+=a==1?1:0 })
    const mbti = (s.E>=s.I?"E":"I")+(s.S>=s.N?"S":"N")+(s.T>=s.F?"T":"F")+(s.J>=s.P?"J":"P")
    // 计算各维度占比（可视化）
    const pairs = [
      {label:"精力", left:"E 外向", right:"I 内向", l:s.E, r:s.I},
      {label:"认知", left:"S 现实", right:"N 直觉", l:s.S, r:s.N},
      {label:"决策", left:"T 理性", right:"F 感性", l:s.T, r:s.F},
      {label:"生活", left:"J 计划", right:"P 随性", l:s.J, r:s.P},
    ]
    const bars = pairs.map(p => {
      const total = p.l + p.r || 1
      return {
        label: p.label, left: p.left, right: p.right,
        leftPct: Math.round(p.l/total*100), rightPct: Math.round(p.r/total*100),
      }
    })
    const shareTitle = `我测出是${mbti}型人格，超准！你也来测测你的心`
    this.setData({ resultType: mbti, bars, shareTitle })
    this.aiAnalyze(`用户是${mbti}型人格。作为心理咨询师，请分析：1.性格画像5句（具体有温度）2.职业方向3个（各一句话）3.感情/社交建议3句 4.一句成长建议。用「」标出金句。总共400字以内。`)
  },
  careerResult(answers) {
    if (answers.length > 12) answers = answers.slice(0, 12)
    const t=[0,0,0,0]; answers.forEach(a=>{ if(a>=0&&a<4) t[a]++ })
    const types=["分析型","社交型","创意型","执行型"]
    const best=types[t.indexOf(Math.max(...t))]
    const shareTitle = `测出我的天赋类型是「${best}」，你的是什么？`
    this.setData({ resultType: best, shareTitle })
    this.aiAnalyze(`用户是${best}人才。请给出：1.天赋描述2句 2.最适合的3个职业（各一句话+为什么适合）3.一条发展建议。用「」标出金句。总共250字以内。`)
  },
  aiAnalyze(prompt) {
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: { model: g.model, messages: [{role:"user",content:prompt}], max_tokens: 600 },
      success: (r) => {
        this.setData({ analysis: r.data.choices?.[0]?.message?.content || "分析失败", loading: false })
      },
      fail: () => this.setData({ analysis: "网络异常，请重试", loading: false })
    })
  },
  // 分享到微信
  onShareAppMessage() {
    return {
      title: this.data.shareTitle || "测测你的心 - AI懂你",
      path: "/pages/index/index",
    }
  },
  // 生成分享图片（Canvas）
  makeShareCard() {
    const type = this.data.resultType
    wx.showLoading({ title: "生成中..." })
    // 画布尺寸 300x400（逻辑像素）
    const ctx = wx.createCanvasContext("shareCanvas", this)
    // 背景渐变
    const grad = ctx.createLinearGradient(0, 0, 300, 400)
    grad.addColorStop(0, "#6C5CE7")
    grad.addColorStop(1, "#a29bfe")
    ctx.setFillStyle(grad)
    ctx.fillRect(0, 0, 300, 400)
    // 标题
    ctx.setFillStyle("#ffffff")
    ctx.setFontSize(20)
    ctx.setTextAlign("center")
    ctx.fillText("测测你的心", 150, 70)
    // 类型
    ctx.setFontSize(44)
    ctx.fillText(type, 150, 150)
    // 副文案
    ctx.setFontSize(14)
    ctx.fillText("原来我是这种性格", 150, 190)
    ctx.fillText("扫码测测你的心", 150, 350)
    // 二维码占位（真实码用小程序码替换）
    ctx.setFillStyle("#ffffff")
    ctx.fillRect(105, 230, 90, 90)
    ctx.setFontSize(12)
    ctx.fillText("小程序码", 150, 278)
    ctx.draw(false, () => {
      wx.hideLoading()
      // 导出图片
      setTimeout(() => {
        wx.canvasToTempFilePath({
          canvasId: "shareCanvas",
          success: (res) => {
            // 保存到相册
            wx.saveImageToPhotosAlbum({
              filePath: res.tempFilePath,
              success: () => wx.showToast({ title: "已保存，快去分享吧", icon: "success" }),
              fail: () => wx.showModal({ title: "提示", content: "需要授权相册权限", confirmText: "去设置", success: (r) => { if (r.confirm) wx.openSetting() } }),
            })
          },
          fail: () => wx.hideLoading(),
        }, this)
      }, 300)
    })
  },
  goHome() { wx.reLaunch({ url: "/pages/index/index" }) }
})
