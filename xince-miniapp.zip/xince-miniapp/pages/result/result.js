const app = getApp()

// 20题MBTI维度定义（与test.js一致）
const MBTI_DIMS = [
  "EI","SN","TF","JP","EI","SN","TF","JP",
  "EI","SN","TF","JP","EI","SN","TF","JP",
  "EI","SN","TF","JP",
]

// 清理AI返回的Markdown符号（星号/#/等）
function cleanAI(text) {
  if (!text) return text
  return text
    .replace(/\*\*/g, "")      // 双星号
    .replace(/\*/g, "")         // 单星号
    .replace(/#{1,6}\s?/g, "")  // 井号
    .replace(/`/g, "")           // 反引号
    .trim()
}

Page({
  data: {
    loading: true, resultType: "", analysis: "",
    bars: [],          // 可视化数据 [{label, left, right, leftPct, rightPct}]
    shareTitle: "",    // 分享标题
  },
  onLoad(options) {
    const type = options.type || "mbti"
    this.setData({ type })
    const answers = wx.getStorageSync(type + "_answers") || []
    if (type === "mbti") this.mbtiResult(answers)
    else this.careerResult(answers)
  },
  mbtiResult(answers) {
    if (answers.length > MBTI_DIMS.length) answers = answers.slice(0, MBTI_DIMS.length)
    const s = {E:0,I:0,S:0,N:0,T:0,F:0,J:0,P:0}
    answers.forEach((a,i) => { const d=MBTI_DIMS[i]; s[d[0]]+=a==0?1:0; s[d[1]]+=a==1?1:0 })
    const mbti = (s.E>=s.I?"E":"I")+(s.S>=s.N?"S":"N")+(s.T>=s.F?"T":"F")+(s.J>=s.P?"J":"P")
    // 计算各维度占比（可视化）
    const pairs = [
      {label:"精力", left:"E 外向", right:"I 内向", l:s.E, r:s.I},
      {label:"认知", left:"S 现实", right:"N 直觉", l:s.S, r:s.N},
      {label:"决策", left:"T 理性", right:"F 感性", l:s.T, r:s.F},
      {label:"生活", left:"J 计划", right:"P 随性", l:s.J, r:s.P},
    ]
    const bars = pairs.map(p => {
      const total = p.l + p.r || 1
      return {
        label: p.label, left: p.left, right: p.right,
        leftPct: Math.round(p.l/total*100), rightPct: Math.round(p.r/total*100),
      }
    })
    const shareTitle = `我测出是${mbti}型人格，超准！你也来测测你的心`
    this.setData({ resultType: mbti, bars, shareTitle })
    this.aiAnalyze(`用户测出是${mbti}型人格。用朋友聊天的调皮语气夸TA，简短点。给出：1.性格3句话 2.适合职业2个 3.感情建议1句 4.金句1句。每段用emoji分隔，别用冒号别用星号，总共150字以内。`)
  },
  careerResult(answers) {
    if (answers.length > 12) answers = answers.slice(0, 12)
    const t=[0,0,0,0]; answers.forEach(a=>{ if(a>=0&&a<4) t[a]++ })
    const types=["分析型","社交型","创意型","执行型"]
    const best=types[t.indexOf(Math.max(...t))]
    const shareTitle = `测出我的天赋类型是「${best}」，你的是什么？`
    this.setData({ resultType: best, shareTitle })
    this.aiAnalyze(`用户测出是${best}人才。用朋友聊天语气简短夸TA。给出：1.天赋1-2句 2.适合职业2个各一句话 3.建议1句。用emoji分隔，别冒号别星号，总共120字以内。`)
  },
  aiAnalyze(prompt) {
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: { model: g.model, messages: [{role:"user",content:prompt}], max_tokens: 800 },
      timeout: 20000,
      success: (r) => {
        this.setData({ analysis: cleanAI(r.data.choices?.[0]?.message?.content) || "分析失败", loading: false })
      },
      fail: () => this.setData({ analysis: "网络异常，请重试", loading: false })
    })
  },
  // 分享到微信
  onShareAppMessage() {
    return {
      title: this.data.shareTitle || "测测你的心 - AI懂你",
      path: "/pages/index/index",
    }
  },
  // 生成分享图片（Canvas v2 - 带真实小程序码+类型标签）
  makeShareCard() {
    const type = this.data.resultType
    const typeInfo = {
      "INTJ":{emoji:"🧠",tag:"战略家"}, "INTP":{emoji:"🔬",tag:"思想家"},
      "ENTJ":{emoji:"👑",tag:"指挥官"}, "ENTP":{emoji:"💡",tag:"发明家"},
      "INFJ":{emoji:"🕊️",tag:"引路人"}, "INFP":{emoji:"🌙",tag:"治愈者"},
      "ENFJ":{emoji:"🌟",tag:"教育家"}, "ENFP":{emoji:"🦋",tag:"追梦人"},
      "ISTJ":{emoji:"📋",tag:"守护者"}, "ISFJ":{emoji:"🤝",tag:"保护者"},
      "ESTJ":{emoji:"🏛️",tag:"管理者"}, "ESFJ":{emoji:"🎭",tag:"组织者"},
      "ISTP":{emoji:"🔧",tag:"工匠"}, "ISFP":{emoji:"🎨",tag:"艺术家"},
      "ESTP":{emoji:"🔥",tag:"冒险家"}, "ESFP":{emoji:"🎉",tag:"表演者"},
    }
    const info = typeInfo[type] || {emoji:"✨", tag:"独特的人"}
    wx.showLoading({ title: "生成中..." })
    const ctx = wx.createCanvasContext("shareCanvas", this)
    const W = 300, H = 400
    // 深色渐变背景
    const grad = ctx.createLinearGradient(0, 0, W, H)
    grad.addColorStop(0, "#2d1b69")
    grad.addColorStop(0.6, "#6C5CE7")
    grad.addColorStop(1, "#1a1a2e")
    ctx.setFillStyle(grad)
    ctx.fillRect(0, 0, W, H)
    // 装饰圆
    ctx.setFillStyle("rgba(255,255,255,0.08)")
    ctx.beginPath(); ctx.arc(260, 60, 80, 0, Math.PI*2); ctx.fill()
    ctx.beginPath(); ctx.arc(30, 350, 50, 0, Math.PI*2); ctx.fill()
    // 顶部emoji
    ctx.setFontSize(34); ctx.setTextAlign("center")
    ctx.fillText(info.emoji, 150, 55)
    // 类型大字
    ctx.setFillStyle("#ffffff"); ctx.setFontSize(42)
    ctx.fillText(type, 150, 110)
    // 标签
    ctx.setFillStyle("rgba(255,255,255,0.9)"); ctx.setFontSize(16)
    ctx.fillText(`「${info.tag}」型人格`, 150, 140)
    // 分隔线
    ctx.setStrokeStyle("rgba(255,255,255,0.3)")
    ctx.beginPath(); ctx.moveTo(70, 160); ctx.lineTo(230, 160); ctx.stroke()
    // 好奇钩子
    ctx.setFontSize(14)
    ctx.fillText("原来我是这种性格", 150, 185)
    ctx.fillText("你呢？敢来测测吗", 150, 205)
    // 真实小程序码（从images加载）
    ctx.drawImage("/images/qrcode.jpg", 105, 225, 90, 90)
    // 底部
    ctx.setFontSize(12); ctx.setFillStyle("#ffffff")
    ctx.fillText("测测你的心 · AI懂你", 150, 335)
    ctx.setFontSize(10); ctx.setFillStyle("rgba(255,255,255,0.6)")
    ctx.fillText("长按识别 测出你的性格", 150, 355)
    ctx.draw(false, () => {
      wx.hideLoading()
      setTimeout(() => {
        wx.canvasToTempFilePath({
          canvasId: "shareCanvas",
          success: (res) => {
            wx.saveImageToPhotosAlbum({
              filePath: res.tempFilePath,
              success: () => wx.showToast({ title: "已保存，快去分享吧", icon: "success" }),
              fail: () => wx.showModal({ title: "提示", content: "需要授权相册权限", confirmText: "去设置", success: (r) => { if (r.confirm) wx.openSetting() } }),
            })
          },
          fail: () => wx.hideLoading(),
        }, this)
      }, 300)
    })
  },
  goHome() { wx.reLaunch({ url: "/pages/index/index" }) },
  retryTest() {
    const type = this.data.type || "mbti"
    wx.removeStorageSync(type + "_answers")
    wx.redirectTo({ url: `/pages/test/test?type=${type}` })
  }
})
