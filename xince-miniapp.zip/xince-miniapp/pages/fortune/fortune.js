const app = getApp()

Page({
  data: { loading: true, level: "", text: "", date: "", keyword: "", shareTitle: "" },
  onLoad() { this.getFortune() },
  getFortune() {
    this.setData({ loading: true })
    const g = app.globalData
    const now = new Date()
    const dateStr = `${now.getMonth()+1}月${now.getDate()}日`
    // 今日关键词（本地随机，快）
    const keywords = ["向内探索", "主动出击", "耐心等待", "破圈社交", "专注当下", "勇敢表达", "复盘成长", "温柔坚定"]
    const keyword = keywords[Math.floor(Math.random()*keywords.length)]
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: {
        model: g.model,
        messages: [{ role: "user", content: `用调皮的语气写今日运势，别冒号别官方腔。包含：整体运势1句 🍀幸运数字1个 🎨幸运颜色1个 ✅宜做的事1件 ⚠️忌的事1件 💡行动建议1句。80字以内，像好朋友八卦你的星座运程` }],
        max_tokens: 300,
        timeout: 20000
      },
      success: (r) => {
        const text = r.data.choices?.[0]?.message?.content || "今天是平静的一天"
        const levels = ["🌟 大吉", "✨ 吉", "☁️ 平平", "🌧️ 注意"]
        const level = levels[Math.floor(Math.random()*levels.length)]
        const shareTitle = `今日${keyword} · ${level}，你也来抽一张？`
        this.setData({ text, level, date: dateStr, keyword, shareTitle, loading: false })
      },
      fail: () => this.setData({ text: "网络异常", level: "☁️", date: dateStr, keyword, loading: false })
    })
  },
  refresh() { this.getFortune() },
  onShareAppMessage() {
    return {
      title: this.data.shareTitle || `今日运势 · ${this.data.level}`,
      path: "/pages/fortune/fortune",
    }
  },
  goHome() { wx.navigateBack() }
})
