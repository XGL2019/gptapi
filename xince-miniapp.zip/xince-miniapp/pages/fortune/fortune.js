const app = getApp()

Page({
  data: { loading: true, level: "", text: "", date: "" },
  onLoad() { this.getFortune() },
  getFortune() {
    this.setData({ loading: true })
    const g = app.globalData
    const now = new Date()
    const dateStr = `${now.getMonth()+1}月${now.getDate()}日`
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: {
        model: g.model,
        messages: [{ role: "user", content: `写一段今日运势，包含：整体运势1句、幸运数字1个、幸运颜色1个、宜1件事、忌1件事。50字以内` }],
        max_tokens: 200
      },
      success: (r) => {
        const text = r.data.choices?.[0]?.message?.content || "今天是平静的一天"
        const levels = ["🌟 大吉", "✨ 吉", "☁️ 平平", "🌧️ 注意"]
        this.setData({ text, level: levels[Math.floor(Math.random()*levels.length)], date: dateStr, loading: false })
      },
      fail: () => this.setData({ text: "网络异常", level: "☁️", date: dateStr, loading: false })
    })
  },
  refresh() { this.getFortune() },
  goHome() { wx.navigateBack() }
})
