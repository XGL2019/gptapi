const app = getApp()

Page({
  data: { dream: "", loading: true, result: "", history: [], showHistory: false },
  onLoad(options) {
    const dream = decodeURIComponent(options.dream || "")
    this.setData({ dream })
    // 加载历史记录
    const history = wx.getStorageSync("dream_history") || []
    this.setData({ history })
    this.interpret(dream)
  },
  interpret(dream) {
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: {
        model: g.model,
        messages: [
          { role: "system", content: "你是超懂梦的朋友，语气调皮轻松，别官方腔别冒号。从三个角度聊：🌙传统说法1句 🧠心理分析1句 💡贴心建议1句。多用emoji，像损友分析TA的梦。每次不超过200字。" },
          { role: "user", content: `我梦见：${dream}` }
        ],
        max_tokens: 400,
        timeout: 20000
      },
      success: (res) => {
        const result = res.data.choices?.[0]?.message?.content || "解梦失败"
        // 存入历史记录（最多10条）
        const history = wx.getStorageSync("dream_history") || []
        const date = new Date()
        const now = `${date.getMonth()+1}月${date.getDate()}日 ${date.getHours()}:${String(date.getMinutes()).padStart(2,"0")}`
        history.unshift({ dream, result, time: now })
        wx.setStorageSync("dream_history", history.slice(0, 10))
        this.setData({ result, loading: false, history: history.slice(0, 10) })
      },
      fail: () => {
        this.setData({ result: "网络异常，请稍后再试", loading: false })
      }
    })
  },
  toggleHistory() { this.setData({ showHistory: !this.data.showHistory }) },
  goHome() { wx.navigateBack() }
})
