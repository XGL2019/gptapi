// 清理AI返回的Markdown符号
function cleanAI(text) {
  if (!text) return text
  return text.replace(/\*\*/g, "").replace(/\*/g, "").replace(/#{1,6}\s?/g, "").replace(/`/g, "").trim()
}

// ===== 周公解梦传统词库（常见梦境） =====
const DREAM_BOOK = {
  "蛇": "梦见蛇，古书云「梦蛇者，主得财」。蛇在传统解梦中多主财帛与贵人：大蛇主大财，小蛇主小利。若梦中无惧，则近期有意外之喜；若心生恐惧，是提示你避小人是非。日常留心身边机会，财运自来。",
  "掉牙": "梦见掉牙，民间说法「掉牙主亲人有恙」，但古本《周公解梦》云「齿落更生，主子孙有吉」。实为家中长辈安康之兆，也预示你即将「换新」——旧事翻篇，新机将至。不必忧虑，顺其自然。",
  "水": "梦见水，主财亦主运。《周公解梦》曰「水旺主财，清者为吉」。清水主财运亨通、心情舒畅；浑水则提示近期事务繁乱，宜梳理心绪。大水主大运将至，静水主平安顺遂。",
  "被追": "梦见被追，是内心压力的外显。古解「奔逃主身有担」，你近期或有所焦虑之事。解梦云：被追而逃脱主化险为夷，被追而跌倒则提示宜放缓脚步、量力而行。放下心事，前路自宽。",
  "飞翔": "梦见飞翔，大吉之兆。《周公解梦》云「身飞上天，主大贵」。飞翔主志向高远、事业腾飞；飞得越高，前程越广。若飞行吃力，则提示近期目标略高，宜脚踏实地。",
  "考试": "梦见考试，主自我审视。古解「应试主名，中者主成」。考试顺利主近期之事可成；考砸则提示内心对某事的担忧。此梦多现于关键抉择前，是内心在帮你「预演」，放宽心即可。",
  "死人": "梦见已故之人，非凶兆。《周公解梦》云「见故人，主有远信」。先人入梦多主报平安、赐福泽，也提示你思念之情。若有未尽之事，可心中默念，自得安宁。",
  "结婚": "梦见结婚，主喜事临门。古解「婚嫁主喜，合者主和」。未婚者梦见，主姻缘将近；已婚者梦见，主家庭和睦。此梦亦主事业「联姻」——合作、签约之事将有进展。",
  "掉水里": "梦见落水，主情绪波动。古解「落水主险，出者主安」。若能上岸，则主渡过难关；若沉溺水中，则提示近期压力较大，宜找人倾诉。水亦主财，落水也可解为「财来财去」，平常心待之。",
  "血": "梦见血，主精力与运势。古解「见血主财，红者主喜」。出血主破财消灾，见他人血主有喜讯。若梦中无痛感，则多为精力旺盛之象；若有痛感，宜多休息养神。",
  "掉发": "梦见掉发，主释怀与更新。古解「发落主忧，落而复生主吉」。掉发主你正放下烦恼，如古人云「三千烦恼丝」——脱落即卸下。若是新发长出，则主新气象将至。",
  "下雨": "梦见下雨，主财主润。古解「雨落主财，甘霖主吉」。细雨润物主财运渐进；暴雨主情绪宣泄后的平静。雨后必有晴，此梦多主「先难后易」，好事在后头。",
  "爬山": "梦见爬山，主事业攀登。古解「登山主贵，至顶主成」。爬至山顶主事将成；半途而废则提示坚持。山高路陡，正是你近期努力的写照——登顶在望。",
  "迷路": "梦见迷路，主方向之惑。古解「迷路主惑，寻得路主明」。此梦提示你近期对某事有些迷茫，但梦中找到路则主心中已有答案。静心自问，前路自明。",
  "捡钱": "梦见捡钱，主意外之喜。古解「得财主喜，拾者主吉」。捡钱主近期有意外收获或贵人相助；若是捡了又丢，则提示机会稍纵即逝，宜早做决断。",
  "梳头": "梦见梳头，主理顺心境。古解「梳发主顺，理者主安」。此梦主近期烦心事将理顺，生活回归条理。长发主长久，短发主新变——不论长短，皆是好兆。",
}

function matchBook(dream) {
  for (const key in DREAM_BOOK) {
    if (dream.includes(key)) return DREAM_BOOK[key]
  }
  return null
}

const app = getApp()

Page({
  data: { dream: "", loading: true, result: "", history: [], showHistory: false, shareTitle: "" },
  onLoad(options) {
    const dream = decodeURIComponent(options.dream || "")
    this.setData({ dream })
    const history = wx.getStorageSync("dream_history") || []
    this.setData({ history })
    this.interpret(dream)
  },
  interpret(dream) {
    // 1. 先查传统词库
    const bookResult = matchBook(dream)
    if (bookResult) {
      this.finish(dream, bookResult)
      return
    }
    // 2. 词库没有的，用AI兜底（传统风格）
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: {
        model: g.model,
        messages: [
          { role: "system", content: "你是周公解梦的传人，语气古朴亲切。按传统解梦思路回答：先说古意（参考《周公解梦》风格），再给一句当代白话建议。用🌙分隔两句，别冒号别星号，总共100字以内。" },
          { role: "user", content: `我梦见：${dream}` }
        ],
        max_tokens: 600,
        timeout: 20000
      },
      success: (res) => {
        const result = cleanAI(res.data.choices?.[0]?.message?.content) || "解梦失败"
        this.finish(dream, result)
      },
      fail: () => {
        this.setData({ result: "网络异常，请稍后再试", loading: false })
      }
    })
  },
  finish(dream, result) {
    const history = wx.getStorageSync("dream_history") || []
    const date = new Date()
    const now = `${date.getMonth()+1}月${date.getDate()}日 ${date.getHours()}:${String(date.getMinutes()).padStart(2,"0")}`
    history.unshift({ dream, result, time: now })
    wx.setStorageSync("dream_history", history.slice(0, 10))
    const shortDream = dream.length > 12 ? dream.slice(0, 12) + "…" : dream
    const shareTitle = `我梦见「${shortDream}」，周公说…你也来测测你的梦`
    this.setData({ result, loading: false, history: history.slice(0, 10), shareTitle })
    // 埋点：解梦完成
    wx.reportAnalytics("test_complete", { type: "dream" })
  },
  toggleHistory() { this.setData({ showHistory: !this.data.showHistory }) },
  goHome() { wx.navigateBack() },
  // 分享给好友
  onShareAppMessage() {
    wx.reportAnalytics("share_event", { channel: "friend", type: "dream" })
    return {
      title: this.data.shareTitle || "测测你的心 - 周公解梦",
      path: `/pages/dream/dream?dream=${encodeURIComponent(this.data.dream || "")}`,
    }
  },
  // 分享到朋友圈
  onShareTimeline() {
    wx.reportAnalytics("share_event", { channel: "timeline", type: "dream" })
    return {
      title: this.data.shareTitle || "测测你的心 - 周公解梦",
      query: `dream=${encodeURIComponent(this.data.dream || "")}`,
    }
  }
})
