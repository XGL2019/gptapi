const app = getApp()

Page({
  data: { dream: "", loading: true, result: "" },
  onLoad(options) {
    const dream = decodeURIComponent(options.dream || "")
    this.setData({ dream })
    this.interpret(dream)
  },
  interpret(dream) {
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: {
        model: g.model,
        messages: [
          { role: "system", content: "你是解梦师。从三个角度：🌙传统解读1句、🧠心理分析1句、💡建议1句。像朋友聊天。每次回复不超过150字。" },
          { role: "user", content: `我梦见：${dream}` }
        ],
        max_tokens: 300
      },
      success: (res) => {
        const result = res.data.choices?.[0]?.message?.content || "解梦失败"
        this.setData({ result, loading: false })
      },
      fail: () => {
        this.setData({ result: "网络异常，请稍后再试", loading: false })
      }
    })
  },
  goHome() { wx.navigateBack() }
})
