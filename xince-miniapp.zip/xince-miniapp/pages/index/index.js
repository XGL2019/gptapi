Page({
  data: { dreamText: "" },
  onDreamInput(e) { this.setData({ dreamText: e.detail.value }) },
  goTest(e) {
    const type = e.currentTarget.dataset.type
    wx.navigateTo({ url: `/pages/test/test?type=${type}` })
  },
  goDream() {
    const dream = this.data.dreamText.trim()
    if (!dream) return wx.showToast({ title: "请输入梦境", icon: "none" })
    wx.navigateTo({ url: `/pages/dream/dream?dream=${encodeURIComponent(dream)}` })
  },
  quickDream(e) {
    const dream = e.currentTarget.dataset.text || "梦见蛇"
    this.setData({ dreamText: dream })
    this.goDream()
  },
  scrollToDream() {
    wx.pageScrollTo({ scrollTop: 600, duration: 300 })
  },
  goFortune() {
    wx.navigateTo({ url: "/pages/fortune/fortune" })
  }
})
