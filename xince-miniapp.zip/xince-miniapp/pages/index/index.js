const TIPS = [
  { emoji: "🧠", title: "每天三件好事", desc: "睡前写下今天的三件小确幸，幸福感会悄悄变高" },
  { emoji: "🌿", title: "给自己放个假", desc: "大脑需要休息，发呆也是一种充电" },
  { emoji: "💬", title: "说出来就好", desc: "情绪憋着会发酵，找人聊聊能卸下一半重量" },
  { emoji: "🏃", title: "动起来", desc: "散步10分钟，焦虑值能降一截" },
]

Page({
  data: { dreamText: "", tips: TIPS },
  onDreamInput(e) { this.setData({ dreamText: e.detail.value }) },
  goTest(e) {
    const type = e.currentTarget.dataset.type
    wx.navigateTo({ url: `/pages/test/test?type=${type}` })
  },
  goDream() {
    const dream = this.data.dreamText.trim()
    if (!dream) return wx.showToast({ title: "请输入梦境", icon: "none" })
    wx.navigateTo({ url: `/pages/dream/dream?dream=${encodeURIComponent(dream)}` })
  },
  quickDream(e) {
    const dream = e.currentTarget.dataset.text || "梦见蛇"
    this.setData({ dreamText: dream })
    this.goDream()
  },
  scrollToDream() {
    wx.pageScrollTo({ scrollTop: 600, duration: 300 })
  },
  goFortune() {
    wx.navigateTo({ url: "/pages/fortune/fortune" })
  }
})
