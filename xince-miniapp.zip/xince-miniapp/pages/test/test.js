const MBTI = [
  {id:1, q:"参加聚会后你通常？", a:["精力充沛还想聊","筋疲力尽需独处"], dim:"EI"},
  {id:2, q:"做决定时更依赖？", a:["具体事实和数据","直觉和整体感觉"], dim:"SN"},
  {id:3, q:"同事哭了，你先？", a:["分析问题出在哪","先安慰情绪"], dim:"TF"},
  {id:4, q:"旅行前你的习惯？", a:["详细行程表","到了再说"], dim:"JP"},
  {id:5, q:"更享受哪种工作？", a:["团队头脑风暴","独自深入研究"], dim:"EI"},
  {id:6, q:"看画先注意什么？", a:["颜色构图细节","整体氛围感受"], dim:"SN"},
  {id:7, q:"朋友做蠢事你？", a:["直接指出问题","委婉安慰"], dim:"TF"},
  {id:8, q:"截止日前一天？", a:["按计划已完成","疯狂赶工中"], dim:"JP"},
]

const CAREER = [
  {id:1,q:"周末更喜欢？",a:["研究有趣问题","朋友聚会","动手做东西","规划安排"]},
  {id:2,q:"别人怎么描述你？",a:["逻辑清晰","善于沟通","有创意","可靠负责"]},
  {id:3,q:"工作最易进入状态？",a:["沉浸思考","快速切换","动手实验","逐步完成"]},
  {id:4,q:"遇新问题通常？",a:["查资料分析","问别人意见","直接试错","列计划"]},
  {id:5,q:"更在意什么？",a:["是否正确","别人开心","是否创新","按时完成"]},
  {id:6,q:"理想办公环境？",a:["安静独立","热闹开放","灵活自由","整洁有序"]},
]

Page({
  data: { type:"", title:"", questions:[], current:0, answers:[], total:0 },
  onLoad(options) {
    const type = options.type
    const qs = type === "mbti" ? MBTI : CAREER
    const title = type === "mbti" ? "MBTI 性格测试" : "职业天赋测试"
    this.setData({ type, title, questions: qs, total: qs.length })
  },
  select(e) {
    const idx = e.currentTarget.dataset.idx
    let answers = this.data.answers
    answers.push(idx)
    const next = this.data.current + 1
    if (next >= this.data.total) {
      wx.setStorageSync(this.data.type + "_answers", answers)
      wx.redirectTo({ url: `/pages/result/result?type=${this.data.type}` })
    } else {
      this.setData({ current: next, answers })
    }
  }
})
