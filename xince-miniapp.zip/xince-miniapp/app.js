App({
  globalData: {
    apiBase: "https://ark.cn-beijing.volces.com/api/v3",
    apiKey: "ark-1fa4f89b-23fd-4d72-b6bb-7024ff4f10fd-f2a03",
    model: "doubao-seed-2-1-pro-260628"
  }
})
