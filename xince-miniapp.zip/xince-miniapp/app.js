App({
  globalData: {
    apiBase: "https://api.deepseek.com/v1",
    apiKey: "sk-c5afc6777ec944c7b04fb9b07c2ecd60",
    model: "deepseek-v4-flash"
  }
})
