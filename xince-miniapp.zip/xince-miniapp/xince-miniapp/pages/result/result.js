const app = getApp()
// MBTI 维度: 必须与test.js的20题一一对应
const MBTI_DIM = [
  {dim:"EI"},{dim:"EI"},{dim:"EI"},{dim:"EI"},{dim:"EI"},
  {dim:"SN"},{dim:"SN"},{dim:"SN"},{dim:"SN"},{dim:"SN"},
  {dim:"TF"},{dim:"TF"},{dim:"TF"},{dim:"TF"},{dim:"TF"},
  {dim:"JP"},{dim:"JP"},{dim:"JP"},{dim:"JP"},{dim:"JP"},
]

// MBTI 16型简介
const MBTI_BRIEF = {
  "INTJ":"建筑师：冷静的战略家，擅长长远规划，喜欢独处思考",
  "INTP":"逻辑学家：安静的分析师，对理论和抽象概念着迷",
  "ENTJ":"指挥官：天生的领导者，果断高效，掌控大局",
  "ENTP":"辩论家：机智的创新者，享受智力挑战和头脑风暴",
  "INFJ":"提倡者：安静而神秘，有深刻的洞察力和理想主义",
  "INFP":"调停者：内心丰富的理想主义者，追求意义和真实",
  "ENFJ":"主人公：富有魅力的引导者，善于激励他人成长",
  "ENFP":"竞选者：热情的自由灵魂，充满创意和可能性",
  "ISTJ":"物流师：可靠的实干家，重视秩序和传统",
  "ISFJ":"守护者：默默付出的保护者，温暖而细致",
  "ESTJ":"总经理：高效的管理者，务实且执行力强",
  "ESFJ":"执政官：热心的照顾者，善于维护关系和谐",
  "ISTP":"鉴赏家：冷静的动手派，擅长解决具体问题",
  "ISFP":"探险家：温柔的自由艺术灵魂，活在当下",
  "ESTP":"企业家：大胆的行动派，享受刺激和挑战",
  "ESFP":"表演者：随性的开心果，用热情感染身边的人",
}

Page({
  data: { loading: true, resultType: "", analysis: "", brief: "", showShare: false },
  onLoad(options) {
    const type = options.type || "mbti"
    const answers = wx.getStorageSync(type + "_answers") || []
    if (type === "mbti") this.mbtiResult(answers)
    else this.careerResult(answers)
  },
  mbtiResult(answers) {
    const s = {E:0,I:0,S:0,N:0,T:0,F:0,J:0,P:0}
    answers.forEach((a,i) => {
      const d = MBTI_DIM[i].dim
      s[d[0]] += a==0 ? 1 : 0
      s[d[1]] += a==1 ? 1 : 0
    })
    const mbti = (s.E>=s.I?"E":"I") + (s.S>=s.N?"S":"N") + (s.T>=s.F?"T":"F") + (s.J>=s.P?"J":"P")
    const brief = MBTI_BRIEF[mbti] || ""
    this.setData({ resultType: mbti, brief })

    const prompt = `你是资深心理咨询师。用户测出${mbti}型人格（${brief}）。

请按以下格式回复（共350-400字，要有人味，像在和朋友聊天）：

「性格画像」
用3-4句描述这类人的核心特质，要有画面感，说他们"看似…其实…"

「适合的职业」
列出3个最适合的职业方向，每个配一句为什么（别只说职业名，要说清楚为什么适合）

「感情与社交」
用2-3句聊聊这类人在感情中的表现和需要注意的地方

「给你的一句话」
用一句话收尾，有温度、有洞察，让用户想截图分享

用「」标出段落小标题。语言生动温暖，像朋友聊天。`
    this.aiAnalyze(prompt)
  },
  careerResult(answers) {
    const t=[0,0,0,0]; answers.forEach(a=>{t[a]++})
    const types=["分析型","社交型","创意型","执行型"]
    const best=types[t.indexOf(Math.max(...t))]
    const second=types[t.indexOf(Math.max(...t.filter((_,i)=>types[i]!==best?t[i]:-1)))]
    this.setData({ resultType: best })

    const prompt = `你是职业规划师。用户测试结果是「${best}」人才（第二倾向是「${second}」）。

请按以下格式回复（共250-300字，像知心前辈聊天）：

「你的天赋」
用2句描述这类人的核心天赋和工作优势

「推荐职业」
推荐3个具体职业（要具体到岗位名称，不要泛泛说"技术类"），每个用一句话说明为什么适合你

「发展建议」
给1-2条具体的成长建议，不说空话，要有可操作性

用「」标出小标题。语言真诚温暖。`
    this.aiAnalyze(prompt)
  },
  aiAnalyze(prompt) {
    const g = app.globalData
    wx.request({
      url: `${g.apiBase}/chat/completions`,
      method: "POST",
      header: { "Authorization": `Bearer ${g.apiKey}`, "Content-Type": "application/json" },
      data: { model: g.model, messages: [{role:"user",content:prompt}], max_tokens: 600 },
      success: (r) => {
        const content = r.data.choices?.[0]?.message?.content || "分析失败，请重试"
        this.setData({ analysis: content, loading: false, showShare: true })
        this.generateShareImage()
      },
      fail: () => this.setData({ analysis: "网络异常，请稍后再试", loading: false })
    })
  },
  // 生成分享卡片
  generateShareImage() {
    const type = this.data.resultType
    const ctx = wx.createCanvasContext('shareCanvas')
    // 背景
    ctx.setFillStyle('#faf7f2')
    ctx.fillRect(0, 0, 300, 400)
    // 标题
    ctx.setFillStyle('#7c6ff0')
    ctx.setFontSize(22)
    ctx.setTextAlign('center')
    ctx.fillText('测测你的心', 150, 80)
    // 结果大字
    ctx.setFillStyle('#3d3a35')
    ctx.setFontSize(36)
    ctx.fillText(type, 150, 160)
    // 一句话简介
    ctx.setFontSize(14)
    ctx.setFillStyle('#a8a29e')
    const brief = this.data.brief ? this.data.brief.split('：')[1] || this.data.brief : ''
    ctx.fillText(brief, 150, 200)
    // 底部引导
    ctx.setFillStyle('#7c6ff0')
    ctx.setFontSize(12)
    ctx.fillText('微信搜一搜「测测你的心」', 150, 360)
    ctx.fillText('看看你是什么人格 →', 150, 380)
    ctx.draw()
  },
  // 微信分享
  onShareAppMessage() {
    const type = this.data.resultType
    const titles = {
      "INTJ":"我的MBTI是INTJ 建筑师！你也来测测？",
      "INTP":"我的MBTI是INTP 逻辑学家！你的呢？",
      "ENTJ":"我的MBTI是ENTJ 指挥官！测测你的人格",
      "ENTP":"我的MBTI是ENTP 辩论家！你是什么类型？",
      "INFJ":"我的MBTI是INFJ 提倡者…你的呢？",
      "INFP":"我的MBTI是INFP 调停者！来测测吧",
      "ENFJ":"我的MBTI是ENFJ 主人公！测测你的性格",
      "ENFP":"我的MBTI是ENFP 竞选者！你也来测？",
      "ISTJ":"我的MBTI是ISTJ 物流师！你的类型是？",
      "ISFJ":"我的MBTI是ISFJ 守护者…测测你的",
      "ESTJ":"我的MBTI是ESTJ 总经理！来测测吧",
      "ESFJ":"我的MBTI是ESFJ 执政官！你的呢？",
      "ISTP":"我的MBTI是ISTP 鉴赏家！测测你的人格",
      "ISFP":"我的MBTI是ISFP 探险家！你是什么类型？",
      "ESTP":"我的MBTI是ESTP 企业家！来测测吧",
      "ESFP":"我的MBTI是ESFP 表演者！你的性格是？",
    }
    const title = titles[type] || `我的测试结果是「${type}」，你也来测测？`
    return {
      title: title,
      path: '/pages/index/index',
      imageUrl: ''  // 后续可用canvas导出的图片
    }
  },
  goHome() { wx.reLaunch({ url: "/pages/index/index" }) }
})
